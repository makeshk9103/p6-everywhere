package com.makesh.physicsscanner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** Transparent overlay: drag to draw a box; on release onSelected(box) fires. */
class SelectionView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    var onSelected: ((RectF) -> Unit)? = null
    private var sx = 0f
    private var sy = 0f
    private var box: RectF? = null
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676"); style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val dim = Paint().apply { color = Color.parseColor("#88000000") }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; box = RectF(sx, sy, sx, sy); invalidate() }
            MotionEvent.ACTION_MOVE -> {
                box = RectF(minOf(sx, e.x), minOf(sy, e.y), maxOf(sx, e.x), maxOf(sy, e.y)); invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val r = box
                if (r != null && r.width() > 80f && r.height() > 50f) onSelected?.invoke(RectF(r))
                else { box = null; invalidate() }
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDraw(c: Canvas) {
        val r = box ?: return
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, r.top, dim)
        c.drawRect(0f, r.bottom, w, h, dim)
        c.drawRect(0f, r.top, r.left, r.bottom, dim)
        c.drawRect(r.right, r.top, w, r.bottom, dim)
        c.drawRect(r, border)
    }
}
