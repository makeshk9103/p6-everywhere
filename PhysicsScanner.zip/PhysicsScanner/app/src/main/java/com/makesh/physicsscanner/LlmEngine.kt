package com.makesh.physicsscanner

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** One on-device model. FAST = Qwen2.5-0.5B (fast.task), ACCURATE = Qwen2.5-1.5B (model.task). */
class LlmEngine(private val context: Context, private val fileName: String, val url: String) {
    private var llm: LlmInference? = null

    fun modelFile() = File(context.getExternalFilesDir(null), fileName)
    fun ready(): Boolean = modelFile().exists()

    @Synchronized
    private fun ensure(): LlmInference {
        llm?.let { return it }
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile().absolutePath)
            .setMaxTokens(384)
            .build()
        return LlmInference.createFromOptions(context, opts).also { llm = it }
    }

    /** Load in background at app start so the first answer is quick. */
    fun warmUp() { if (ready()) ensure() }

    @Synchronized
    fun solveMcq(mcq: Mcq, hints: List<String>): String {
        val sb = StringBuilder()
        sb.appendLine("Physics MCQ. Reply with only the correct option letter.")
        if (hints.isNotEmpty()) sb.appendLine("Notes: " + hints.joinToString(" ; "))
        sb.appendLine("Q: ${mcq.stem}")
        mcq.options.forEachIndexed { i, o -> sb.appendLine("${'A' + i}) $o") }
        sb.append("Answer:")
        return ensure().generateResponse(sb.toString())
    }

    @Synchronized
    fun solveOpen(question: String, hints: List<String>): String {
        val sb = StringBuilder()
        sb.appendLine("You are a physics expert. Answer briefly: final answer first, then at most 2 short sentences of reasoning.")
        if (hints.isNotEmpty()) sb.appendLine("Notes: " + hints.joinToString(" ; "))
        sb.appendLine("Question: $question")
        sb.append("Answer:")
        return ensure().generateResponse(sb.toString())
    }
}
