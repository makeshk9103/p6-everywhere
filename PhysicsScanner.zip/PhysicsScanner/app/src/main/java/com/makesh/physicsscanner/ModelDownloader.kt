package com.makesh.physicsscanner

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object ModelDownloader {
    // Accurate: Qwen2.5-1.5B-Instruct (~1.6 GB). Fast: Qwen2.5-0.5B-Instruct (~550 MB). Both open, Apache-2.0.
    const val URL_STR =
        "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
    const val FAST_URL =
        "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"

    /** Blocking. Call from a background thread. onProgress(percent). */
    fun download(url: String, target: File, onProgress: (Int) -> Unit) {
        val part = File(target.parentFile, target.name + ".part")
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000; readTimeout = 30000; instanceFollowRedirects = true
        }
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            part.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L; var last = -1
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != last) { last = pct; onProgress(pct) }
                    }
                }
            }
        }
        if (!part.renameTo(target)) throw IllegalStateException("Rename failed")
    }
}
