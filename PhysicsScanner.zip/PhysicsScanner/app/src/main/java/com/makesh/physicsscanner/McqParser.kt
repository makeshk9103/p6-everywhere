package com.makesh.physicsscanner

/** options empty => open-ended question (no choices). */
data class Mcq(val stem: String, val options: List<String>)

object McqParser {
    private val strong = Regex("""^\(?([A-Da-d])[\)\.\]:]\s*(.*)$""")
    private val radio = Regex("""^[OoQ○◯●©]\s+""")
    private val qnum = Regex("""^\s*\d{1,3}[\.\)]\s+""")
    private val weak = Regex("""^\s*(\(?[A-Da-d1-4][\)\.\]:]|[a-d])\s+""")

    fun clean(raw: String): String = raw
        .replace("\u2212", "-").replace("×", "x").replace("–", "-")
        .replace(Regex("[ \t]+"), " ").trim()

    private fun opt(s: String) = radio.replace(weak.replace(s, ""), "").trim()

    fun parse(raw: String): Mcq {
        val lines = clean(raw).lines().map { it.trim() }.filter { it.isNotEmpty() }
            .filterNot { it.contains("www.", true) || it.contains(".com", true) || it.contains("http", true) }
            .filterNot { it.length == 1 && it[0].uppercaseChar() in 'A'..'D' }

        // 1) Clearly labelled options: A) / B. / (c) ...
        val strongIdx = lines.indices.filter { strong.matches(lines[it]) }
        if (strongIdx.size >= 3) {
            val first = strongIdx.first()
            val stem = qnum.replace(lines.take(first).joinToString(" "), "")
            val opts = mutableListOf<String>()
            for (i in first until lines.size) {
                val m = strong.find(lines[i])
                if (m != null) opts.add(radio.replace(m.groupValues[2].trim(), ""))
                else if (opts.isNotEmpty()) opts[opts.lastIndex] = opts.last() + " " + lines[i]
            }
            return Mcq(stem, opts.take(4))
        }

        // 2) Labels missing/garbled: last 4 short lines = options, rest = question
        if (lines.size in 5..9) {
            val last4 = lines.takeLast(4)
            val stem = qnum.replace(lines.dropLast(4).joinToString(" "), "")
            if (last4.all { it.length <= 60 } && stem.length >= 15)
                return Mcq(stem, last4.map { opt(it) })
        }

        // 3) Open-ended question
        return Mcq(qnum.replace(lines.joinToString(" "), ""), emptyList())
    }
}
