package com.makesh.physicsscanner

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

@androidx.camera.core.ExperimentalGetImage
class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private lateinit var preview: PreviewView
    private lateinit var selection: SelectionView
    private lateinit var setupPanel: View
    private lateinit var setupInfo: TextView
    private lateinit var dlFast: Button
    private lateinit var dlAcc: Button
    private lateinit var dlAll: Button

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val camExecutor = Executors.newSingleThreadExecutor()
    private var capture: ImageCapture? = null
    private var camera: Camera? = null
    private var torchOn = false
    private var runId = 0
    private var downloading = false

    private lateinit var fast: LlmEngine
    private lateinit var acc: LlmEngine
    private lateinit var formulas: FormulaStore

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else output.text = "Camera permission venum."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)

        output = findViewById(R.id.output)
        preview = findViewById(R.id.preview)
        selection = findViewById(R.id.selection)
        setupPanel = findViewById(R.id.setupPanel)
        setupInfo = findViewById(R.id.setupInfo)
        dlFast = findViewById(R.id.dlFastBtn)
        dlAcc = findViewById(R.id.dlAccBtn)
        dlAll = findViewById(R.id.dlAllBtn)

        fast = LlmEngine(this, "fast.task", ModelDownloader.FAST_URL)
        acc = LlmEngine(this, "model.task", ModelDownloader.URL_STR)
        formulas = FormulaStore(this)

        selection.onSelected = { rect -> captureRegion(rect) }
        findViewById<Button>(R.id.torchBtn).setOnClickListener {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(torchOn)
        }
        dlFast.setOnClickListener { download(fast to "FAST") }
        dlAcc.setOnClickListener { download(acc to "ACCURATE") }
        dlAll.setOnClickListener { download(fast to "FAST", acc to "ACCURATE") }

        refreshSetup()
        lifecycleScope.launch(Dispatchers.Default) {
            try { fast.warmUp() } catch (_: Exception) {}
            try { acc.warmUp() } catch (_: Exception) {}
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun refreshSetup() {
        val f = fast.ready(); val a = acc.ready()
        dlAll.visibility = if (!f && !a) View.VISIBLE else View.GONE
        dlFast.visibility = if (!f && a) View.VISIBLE else View.GONE
        dlAcc.visibility = if (f && !a) View.VISIBLE else View.GONE
        setupPanel.visibility = if (f && a) View.GONE else View.VISIBLE
        setupInfo.text = when {
            !f && !a -> "Modhalla model download pannunga (WiFi, oru vaati dhaan). FAST = vegam, ACCURATE = thuliyam. Rendum irundha best."
            !f -> "FAST model add pannina, answer udane varum (quick answer + bigger model confirm)."
            else -> "ACCURATE model add pannina, quick answer-ah confirm/correct pannum."
        }
    }

    private fun download(vararg jobs: Pair<LlmEngine, String>) {
        if (downloading) return
        downloading = true
        lifecycleScope.launch {
            try {
                for ((engine, label) in jobs) {
                    if (engine.ready()) continue
                    withContext(Dispatchers.IO) {
                        ModelDownloader.download(engine.url, engine.modelFile()) { pct ->
                            runOnUiThread { setupInfo.text = "$label model downloading... $pct%  (app close panadhinga)" }
                        }
                    }
                    refreshSetup()
                    launch(Dispatchers.Default) { try { engine.warmUp() } catch (_: Exception) {} }
                }
            } catch (e: Exception) {
                setupInfo.text = "Download fail: ${e.message}. Marupadi thattunga."
            }
            downloading = false
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv, capture)
        }, ContextCompat.getMainExecutor(this))
    }

    /** Take a photo, cut out exactly the dragged box, OCR it, answer it. */
    private fun captureRegion(sel: RectF) {
        val cap = capture ?: return
        if (!fast.ready() && !acc.ready()) {
            output.text = "Modhalla model download pannunga (mela irukkura button)."
            refreshSetup(); return
        }
        val myId = ++runId
        output.text = "Padikkudhu..."
        val vw = preview.width; val vh = preview.height
        cap.takePicture(camExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val crop: Bitmap? = try { cropSelection(image, sel, vw, vh) } catch (t: Throwable) { null }
                image.close()
                if (crop == null) {
                    runOnUiThread { output.text = "Capture problem. Marupadi box podunga." }
                    return
                }
                recognizer.process(InputImage.fromBitmap(crop, 0))
                    .addOnSuccessListener { res -> if (myId == runId) solve(res.text, myId) }
                    .addOnFailureListener { e -> runOnUiThread { output.text = "OCR error: ${e.message}" } }
            }
            override fun onError(e: ImageCaptureException) {
                runOnUiThread { output.text = "Capture error: ${e.message}" }
            }
        })
    }

    private fun cropSelection(image: ImageProxy, sel: RectF, vw: Int, vh: Int): Bitmap {
        val raw = image.toBitmap()
        val m = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()) }
        val photo = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        val w = photo.width.toFloat(); val h = photo.height.toFloat()
        // PreviewView fills the screen centre-cropped: map screen box -> photo pixels
        val s = maxOf(vw / w, vh / h)
        val ox = (vw - w * s) / 2f; val oy = (vh - h * s) / 2f
        val pad = 14f
        val x1 = ((sel.left - pad - ox) / s).coerceIn(0f, w - 1f)
        val y1 = ((sel.top - pad - oy) / s).coerceIn(0f, h - 1f)
        val x2 = ((sel.right + pad - ox) / s).coerceIn(x1 + 1f, w)
        val y2 = ((sel.bottom + pad - oy) / s).coerceIn(y1 + 1f, h)
        return Bitmap.createBitmap(
            photo, x1.toInt(), y1.toInt(),
            (x2 - x1).toInt().coerceAtLeast(1), (y2 - y1).toInt().coerceAtLeast(1)
        )
    }

    private fun letterIndex(reply: String, mcq: Mcq): Int? {
        val l = Regex("\\b([A-D])\\b").find(reply)?.groupValues?.get(1) ?: return null
        val i = l[0] - 'A'
        return if (i < mcq.options.size) i else null
    }

    private fun solve(raw: String, myId: Int) {
        val mcq = McqParser.parse(raw)
        if (mcq.stem.isBlank()) {
            output.text = "Edhuvum padikka mudiyala. Velicham/focus paathu, box-ah question mela podunga."
            return
        }
        val hints = formulas.topK(mcq.stem + " " + mcq.options.joinToString(" "), 2)
        lifecycleScope.launch {
            val t0 = System.currentTimeMillis()
            fun secs() = String.format("%.1f", (System.currentTimeMillis() - t0) / 1000.0)
            try {
                if (mcq.options.size >= 2) {
                    val shown = buildString {
                        appendLine("Q: ${mcq.stem}"); appendLine()
                        mcq.options.forEachIndexed { i, o -> appendLine("${'A' + i}) $o") }
                    }
                    fun fmt(i: Int?) = if (i == null) "?" else "${'A' + i}) ${mcq.options[i]}"
                    output.text = shown + "\nYosikkudhu..."
                    var quick: Int? = null
                    if (fast.ready()) {
                        val r = withContext(Dispatchers.Default) { fast.solveMcq(mcq, hints) }
                        if (myId != runId) return@launch
                        quick = letterIndex(r, mcq)
                        output.text = shown + "\n⚡ " + fmt(quick) + "  (" + secs() + " s)" +
                            (if (acc.ready()) "\n🔍 Bigger model confirm pannudhu..." else "")
                    }
                    if (acc.ready()) {
                        val r = withContext(Dispatchers.Default) { acc.solveMcq(mcq, hints) }
                        if (myId != runId) return@launch
                        val best = letterIndex(r, mcq)
                        val verdict = when {
                            quick == null || best == null -> "✅ " + fmt(best ?: quick)
                            quick == best -> "✅ " + fmt(best) + "  (confirmed)"
                            else -> "🔄 " + fmt(best) + "  (quick guess " + fmt(quick) + " maathittaen)"
                        }
                        output.text = shown + "\n" + verdict + "\n\n⏱ " + secs() + " s"
                    }
                } else {
                    output.text = "Q: ${mcq.stem}\n\nYosikkudhu..."
                    val eng = if (acc.ready()) acc else fast
                    val r = withContext(Dispatchers.Default) { eng.solveOpen(mcq.stem, hints) }
                    if (myId != runId) return@launch
                    output.text = "Q: ${mcq.stem}\n\n💡 " + r.trim() + "\n\n⏱ " + secs() + " s"
                }
            } catch (e: Exception) {
                output.text = "Error: ${e.message}"
            }
        }
    }
}
