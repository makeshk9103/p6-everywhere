# P6 Everywhere (offline physics scanner)
Full-screen camera. Drag a box on the question -> OCR -> answer (MCQ or open question).
Quick answer from FAST model, confirmed/corrected by ACCURATE model. Works offline after one-time model download.

Build: upload this zip as PhysicsScanner.zip to the GitHub repo (workflow unzips it and builds the APK).
